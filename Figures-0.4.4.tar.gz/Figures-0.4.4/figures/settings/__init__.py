"""
Settings plugins for Figures.
"""
