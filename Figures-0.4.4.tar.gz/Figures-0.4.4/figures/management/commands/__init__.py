"""Django management commands for Figures.
"""
