.. _appsembler_install:

=================================
Installing Figures for Appsembler
=================================

This document describes how to install and configure Figures to run in Appsembler's fork of Open edX.


-----------
Placeholder
-----------

This document is currently a placeholder. Stay tuned!
