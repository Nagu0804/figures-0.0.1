export const testReportData = [
  {
    "reportId": "MQR-12-12-17",
    "reportName": "My quarterly report",
    "reportDescription": "My report description goes here and it is just perfect!",
    "dateCreated": "12/12/2017",
  },
  {
    "reportId": "MQR-03-12-18",
    "reportName": "My quarterly report 02",
    "reportDescription": "My another report description goes here and it is just perfect!",
    "dateCreated": "03/12/2017",
  }
]

export default testReportData
