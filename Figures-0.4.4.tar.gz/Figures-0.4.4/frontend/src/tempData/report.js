export const testReportData = {
  "reportId": "MQR-12-12-17",
  "reportName": "My quarterly report",
  "reportDescription": "My report description goes here and it is just perfect!",
  "dateCreated": "12/12/2017",
  "reportAuthor": "Marty McFly",
  "dataStartDate": "",
  "dataEndDate": "",
  "reportCards": [
    {
      "cardName": "TEST"
    }
  ]
}

export default testReportData
